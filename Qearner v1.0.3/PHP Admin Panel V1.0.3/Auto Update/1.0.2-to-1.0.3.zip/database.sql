ALTER TABLE `category` ADD `status` INT(11) NOT NULL DEFAULT '1' AFTER `row_order`;
ALTER TABLE `users` ADD `device_id` VARCHAR(250) NOT NULL AFTER `status`;
INSERT INTO `settings` (`type`, `message`, `status`) VALUES ('in_app_purchase_mode', '1', 0),('in_app_ads_mode', '0', 0),('ads_type', '1', 0),('adAppId', 'test', 0),('admob_Rewarded_Video_Ads', 'test', 0),('admob_interstitial_id', 'test', 0),('admob_banner_id', 'test', 0),('native_unit_id', 'test', 0),('admob_openads_id', 'test', 0),('maintenance_status', '0', 0),('maintenance_message', 'App Under Maintenance', 0);
